# Latest Crunchyroll simulcasts in a click of a button.

## Features:
- Notifies user of all released episodes in Crunchyroll
- Allows user to view last 10 released episodes in Crunchyroll using the pop up
- Allow users to change the number of recently released episodes that can be viewed in the pop up

## Todo:
- Allow users to filter notifications based on the anime they watch (MyAnimeList)
- Suggest more!
